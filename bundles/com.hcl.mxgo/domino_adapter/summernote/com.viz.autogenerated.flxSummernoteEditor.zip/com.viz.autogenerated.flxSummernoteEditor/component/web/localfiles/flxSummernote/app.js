const app = {
	createEditor(){
	  $('#summernote').summernote({
			codeviewFilter: true, // For XSS Protection
			codeviewIframeFilter: true, // For XSS Protection
	  		fontNames: ['Arial', 'Arial Black', 'Century Gothic', 'Comic Sans MS', 'Courier New', 'Helvetica Neue', 'Helvetica', 'Impact', 'Lucida Grande', 'Tahoma', 'Times New Roman', 'Verdana'],
    		fontNamesIgnoreCheck: ['Century Gothic'],
			height: 255,
			toolbar: [
				['style', ['style']],
				['font', ['bold', 'italic', 'underline', 'clear']],
				['fontname', ['fontname']],
				['color', ['color']],
				['para', ['ul', 'ol', 'paragraph']],
				['table', ['table']],
				['insert', ['link', 'picture', 'video', 'file']],
				['view', ['fullscreen', 'codeview', 'help']]
		  ],
		  callbacks: {
			  onFileUpload: function(file) {
				  let result = new Promise ((resolve, reject) => {
					  uploadCallBack(file[0], function(value) {
						  resolve(value);
					  });
					});
					
					result.then((value) => {
					  insertFileToEditor(file[0], value);
						let filesContainer = parent.document.querySelector("#filesContainer");
						if (filesContainer !== null && typeof parent.createRowFile !== "undefined") {
						  parent.manageRowFile(filesContainer, file[0], getFieldName());
					  }
				  });
			  }
		  },
		  tableClassName: function() {
			$(this).addClass('table table-bordered')
			.attr('style', "border: 1px solid black !important; border-collapse: collapse;");

			$(this).find('th')
			.attr('style', "border: 1px solid black !important; padding: 15px;");

			$(this).find('td')
			.attr('style', "border: 1px solid black !important; padding: 15px;");
		  }
	  });
	  function uploadCallBack(file, cb) {
		  let reader = new FileReader();
		  reader.readAsDataURL(file);
		  reader.onload = function() {
			  let inputData = reader.result;
			  let replaceValue = inputData.split(',',"");
			  let base64String = inputData.replace(replaceValue + ".", "");
			  cb(base64String);
		  }
	  }
	  function insertFileToEditor(file, value) {
		  let elem = document.createElement("a");
		  let icon = document.createElement("img");
		  icon.loading = "lazy";
		  icon.src = "/" + window.location.pathname.split('/')[1] + "/desktopweb/images/dataPanel/download.png";
		  icon.style.cssText = "height:13px;width:16px;margin-right:5px;";
		  icon.classList.add("mxgo-fileAttach-icon");
		  elem.appendChild(icon);
		  let linkText = document.createTextNode(file.name);
		  elem.appendChild(linkText);
		  elem.title = file.name;
		  elem.href = "#";
		  elem.download = file.name;
		  elem.classList.add("domino-attachment");
		  $('#summernote').summernote('editor.insertNode', elem);
	  }
	},
	
	setData(data){
	  $('#summernote').summernote('code', data);
	},
	
	getData(){
	  return $('#summernote').summernote('code');
	}
  };
  
  function setData(data) {
	  app.setData(data);
  }
  
  function getData() {
	  return app.getData();
  }
  
  function checkOrRemoveFile(fileName, removeFile) {
		let result = false;
		const parser = new DOMParser();
		let htmlObject = parser.parseFromString(app.getData(), 'text/html');
		let fileList = htmlObject.querySelectorAll('a[class="domino-attachment"]');
		if (typeof fileList !== "undefined" && fileList.length !== 0) {
			fileList.forEach((file) => {
			  if (file.title === fileName) {
				  if (removeFile) {
						file.remove();
				  }
					result = true;
			  }
		  });
			if (removeFile) {
				app.setData(htmlObject.body.innerHTML);
		  }
	  }
		return result;
  }
  
  function getFieldName() {
	  let fieldName = window.frameElement.parentElement.attributes["kwp"].value;
	  fieldName = fieldName.slice(fieldName.indexOf("instance") + 8).split('_')[0];
	  return fieldName;
  } 