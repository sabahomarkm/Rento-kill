define(function() {
  
	return {
		constructor: function(baseConfig, layoutConfig, pspConfig) {

		},
		//Logic for getters/setters of custom properties
		initGettersSetters: function() {
          defineGetter(this, 'data', () => {
            return this.getData();
          });
          defineSetter(this, 'data', value => {
            this._data = this.setData(value);
          });
        },

      	//Places content in Summernote Editor
        setData: function(data){
          if (this.view.summernoteEditorBrowser &&
              this.view.summernoteEditorBrowser._kwebfw_ &&
              this.view.summernoteEditorBrowser._kwebfw_.view && 
              this.view.summernoteEditorBrowser._kwebfw_.view.hasChildNodes && 
              this.view.summernoteEditorBrowser._kwebfw_.view.children[0]) {
            
            let iframe = this.view.summernoteEditorBrowser._kwebfw_.view.children[0];
            if (iframe) {
              if (iframe.contentWindow.setData) {
                iframe.contentWindow.setData(data);
              } else {
                new Promise(function(resolve) {
                  iframe.addEventListener("load", function() {
                    iframe.contentWindow.setData(data);
                    resolve();
                  });
                });
              }
            }
          }
          
          return data;
        },
          
      	//Retrieves content from Summernote Editor
        getData: function(){
          if (this.view.summernoteEditorBrowser &&
              this.view.summernoteEditorBrowser._kwebfw_ &&
              this.view.summernoteEditorBrowser._kwebfw_.view && 
              this.view.summernoteEditorBrowser._kwebfw_.view.hasChildNodes && 
              this.view.summernoteEditorBrowser._kwebfw_.view.children[0]) {
            
            let iframe = this.view.summernoteEditorBrowser._kwebfw_.view.children[0];
            if (iframe) {
              if (iframe.contentWindow.getData) {
                return iframe.contentWindow.getData();
              }
            }
          }
          
          return null;
        },
      
      	//Check in the content of the Summernote Editor if file exists or not, and could also delete the file
      	checkOrRemoveFile: function(fileName, removeFile = false){
          if (this.view.summernoteEditorBrowser &&
              this.view.summernoteEditorBrowser._kwebfw_ &&
              this.view.summernoteEditorBrowser._kwebfw_.view && 
              this.view.summernoteEditorBrowser._kwebfw_.view.hasChildNodes && 
              this.view.summernoteEditorBrowser._kwebfw_.view.children[0]) {
            
            let iframe = this.view.summernoteEditorBrowser._kwebfw_.view.children[0];
            if (iframe) {
              if (iframe.contentWindow.checkOrRemoveFile) {
                return iframe.contentWindow.checkOrRemoveFile(fileName, removeFile);
              } else {
                new Promise(function(resolve) {
                  iframe.addEventListener("load", function() {
                    return iframe.contentWindow.checkOrRemoveFile(fileName, removeFile);
                    resolve();
                  });
                });
              }
            }
          }
        }
	};
});