//
//  NativeFacade.h
//  logger_abc
//
//  Created by MADP on 06/12/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NativeFacade.h"

@interface VoltMXNativeFacade : NativeFacade
@end
