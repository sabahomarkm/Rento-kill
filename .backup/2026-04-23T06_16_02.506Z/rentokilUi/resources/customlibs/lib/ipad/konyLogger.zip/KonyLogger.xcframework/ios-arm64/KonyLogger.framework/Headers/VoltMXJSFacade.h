//
//  JSFacade.h
//  Logger
//
//  Created by Harshini Bonam on 09/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JSFacade.h"

@interface VoltMXJSFacade : JSFacade

- (id)init;
@end
